package com.example.demo1;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class App2Controller {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button BackButton1;

    @FXML
    private Button NextButton;

    @FXML
    void initialize() {
        NextButton.setOnAction(actionEvent -> {
            HelloController HL = new HelloController();
            HL.OpenNewScene(NextButton, "/com/example/demo1/app3.fxml");
        });

        BackButton1.setOnAction(actionEvent -> {
            HelloController HL = new HelloController();
            HL.OpenNewScene(BackButton1, "/com/example/demo1/app1.fxml");
        });

    }

}
