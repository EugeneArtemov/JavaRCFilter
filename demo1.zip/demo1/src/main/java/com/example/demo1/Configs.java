package com.example.demo1;

public class Configs {
    protected String dbHost = "localhost";
    protected String dbPort = "3306";
    protected String dbUser = "root";
    protected String dbPass = "12345";
    protected String dbName = "LabUsers";

}
