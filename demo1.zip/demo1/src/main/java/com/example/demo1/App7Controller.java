package com.example.demo1;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.concurrent.atomic.AtomicInteger;

import javafx.beans.value.ChangeListener;
import javafx.fxml.FXML;
import javafx.scene.chart.*;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;


import javafx.beans.value.ObservableValue;


public class App7Controller {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button BackButton1;

    @FXML
    private TextField C_field;

    @FXML
    private MenuButton Cbutton;

    @FXML
    private MenuButton FCbutton;

    @FXML
    private Button calculationbutton;

    @FXML
    private LineChart<Number, Number> chart;

    @FXML
    private LineChart<Number, Number> chart1;

    @FXML
    private NumberAxis xAxis ;

    @FXML
    private NumberAxis yAxis ;

    @FXML
    private TextField fc_field;

    @FXML
    private TextField f_field1;

    @FXML
    void initialize() {
        chart.setCreateSymbols(false);
        chart1.setCreateSymbols(false);
        calculationbutton.setOnAction(actionEvent -> {
            XYChart.Series<Number, Number>  series = new XYChart.Series<Number, Number>();
            XYChart.Series<Number, Number>  series1 = new XYChart.Series<Number, Number>();
            XYChart.Series<Number, Number>  series2 = new XYChart.Series<Number, Number>();
            XYChart.Series<Number, Number>  series3 = new XYChart.Series<Number, Number>();
            XYChart.Series<Number, Number>  series4 = new XYChart.Series<Number, Number>();
            series.getData().clear();
            series1.getData().clear();
            series2.getData().clear();
            series3.getData().clear();
            series4.getData().clear();
            chart.getData().clear();
            chart1.getData().clear();

            double C = Double.parseDouble(String.valueOf(C_field.getText()));
            double R = Double.parseDouble(String.valueOf(fc_field.getText()));
            double f = Double.parseDouble(String.valueOf(f_field1.getText()));
            double fc = 1.0 / (2*Math.PI * C * R);

            double f1 = fc * 0.2;
            double f2 = fc * 15;

            if (f >= f1 && f <= f2){
                series3.getData().add(new XYChart.Data(f, 0));
                series3.getData().add(new XYChart.Data(f, -25));
            }
                for (double i = f1; i <= f2; i+= (f2 - f1) / 1000) {

                    double Xc = (1.0 / (2 * Math.PI * i * C));
                    double Vout = (Xc / (Math.sqrt((Xc * Xc) + (R * R))));
                    double Db = 20 * Math.log10(Vout);
                    series.getData().add(new XYChart.Data(i, Db));

                }

            series1.getData().add(new XYChart.Data(fc, -3));
            series1.getData().add(new XYChart.Data(0, -3));
            series1.setName("Частота среза");
            chart.getData().add(series);
            chart.getData().add(series1);
            chart.getData().add(series3);
            System.out.println(fc);
                for (double j = 0; j <= 1 / f; j+= 0.001 / f) {
                    double x = Math.sin(2 * Math.PI * j * f);
                    series2.getData().add(new XYChart.Data(j, x));

                    double Xc1 = (1.0 / (2 * Math.PI * f * C));
                    double Vout1 = (Xc1 / (Math.sqrt((Xc1 * Xc1) + (R * R))));
                    double x1 = Math.sin(2 * Math.PI * j * Vout1);
                    series4.getData().add(new XYChart.Data(j, x1));

                }
                chart1.getData().add(series2);
                chart1.getData().add(series4);
            });


    }


}


