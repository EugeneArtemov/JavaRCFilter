package com.example.demo1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RegisterController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField Email_fieldReg;

    @FXML
    private TextField Group_fieldReg;

    @FXML
    private TextField Login_fieldReg;

    @FXML
    private TextField Password_fieldReg;

    @FXML
    private Button authButton1;

    @FXML
    private Label welcomeText;

    @FXML
    void initialize() {
        DBHandler dbHandler = new DBHandler();

        authButton1.setOnAction(actionEvent -> {

            RegNewUser();

            authButton1.getScene().getWindow().hide();
            FXMLLoader loader1 = new FXMLLoader();
            loader1.setLocation(getClass().getResource("/com/example/demo1/hello-view.fxml"));

            try {
                loader1.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root1 = loader1.getRoot();
            Stage stage1 = new Stage();
            stage1.setScene(new Scene(root1));
            stage1.showAndWait();
        });



    }

    private void RegNewUser() {
        DBHandler dbHandler = new DBHandler();


        String login = Login_fieldReg.getText();
        String email = Email_fieldReg.getText();
        String group = Group_fieldReg.getText();
        String password = Password_fieldReg.getText();

        User user = new User(login, email, group, password);

        dbHandler.RegUser(user);

    }

}

