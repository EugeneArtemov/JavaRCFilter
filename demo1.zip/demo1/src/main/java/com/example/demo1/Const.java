package com.example.demo1;

public class Const {
    public static final String USER_TABLE = "users";
    public static final String USERS_ID = "idusers";
    public static final String USERS_NAME = "name";
    public static final String USERS_GROUP = "groupp";
    public static final String USERS_EMAIL = "email";
    public static final String USERS_PASSWORD = "password";
}
